=== WooCommerce Subscriptions ===
Contributors: prospress, jconroy, mattallan, thenbrent
Tags: woocommerce, subscriptions, ecommerce, e-commerce, commerce, wordpress ecommerce
Requires at least: 4.0
Tested up to: 4.8
Requires PHP: 5.6
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html
WC requires at least: 2.5
WC tested up to: 3.2
Woo: 27147:6115e6d7e297b623a169fdcf5728b224
